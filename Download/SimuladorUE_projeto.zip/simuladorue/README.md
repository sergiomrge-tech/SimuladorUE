# SimuladorUE

Simulador de resort em **primeira pessoa**, feito em **Unreal Engine 5.8 (C++)**.
Você começa com um quiosque numa faixa de praia e vai crescendo até um resort completo.

> **Estado atual: protótipo 1 (jogabilidade).** O visual usa formas básicas como
> provisório. A arte final (realista e estilizada, sem low poly) entra depois, com
> assets do Fab/Quixel, Nanite, Lumen e materiais estilizados.

## Como rodar (Windows)

1. Instale a Unreal Engine 5.8 e o Visual Studio 2022 com as cargas
   **"Desenvolvimento de jogos com C++"** e o **Windows SDK**.
2. Baixe o projeto (`git clone` ou ZIP).
3. Clique com o botão direito em `SimuladorUe.uproject` → **Switch Unreal Engine version…**
   (escolha a 5.8) → depois **Generate Visual Studio project files**.
4. Dê dois cliques em `SimuladorUe.uproject`. A Unreal pergunta se quer compilar: **Sim**.
5. Dentro do editor: **File → New Level → Empty Level** e salve em
   `Content/Maps/Praia` (o nome `Praia` é o que o `DefaultEngine.ini` espera).
6. Aperte **Play**. Todo o cenário é montado por código.

Se algo falhar na compilação, copie a mensagem de erro e me mande. Há um roteiro de teste em [TESTE.md](TESTE.md).

## Controles

| Tecla | Ação |
|---|---|
| WASD / mouse | andar / olhar |
| Shift / Espaço | correr / pular |
| **B** | liga/desliga o modo construção |
| Q / E ou roda do mouse | troca a construção selecionada |
| R | gira a construção em 90° |
| Clique esquerdo | constrói |
| X | demole a construção na mira (devolve 50%) |
| F5 / F9 | salva / carrega o jogo (também salva sozinho a cada dia) |
| F7 | novo jogo (apaga o save) |
| 1-4 | compra melhoria da construção na mira |
| F2 / F3 | contrata garçom / faxineiro |
| P | pausa |
| 7 | reforma um quarto do chalé/hotel na mira (+30% na diária dele) |
| - / + | diminui / aumenta o preço da construção na mira |
| Enter | começa o jogo (tela de abertura) |

O save fica em `Saved/resort_save.json`. Ao abrir o jogo, ele continua de onde parou.

## Como o jogo funciona

- Uma bolinha sobre a cabeça do hóspede mostra o humor (verde feliz, amarelo ok, vermelho irritado); filas longas geram reclamações.
- **Hospedes** chegam pela entrada da praia, escolhem construções que podem pagar,
  usam, pagam e vão embora. Satisfação alta vira **prestígio**.
- **Melhorias:** olhe para uma construção (fora do modo construção) e aperte **1-4** para
  instalar melhorias (cardápio, cozinha, cama, armário, frigobar, sauna...). Cada uma custa
  uma parte do valor da construção, aumenta a renda (nos quartos, a diária), a satisfação e a
  manutenção. Uma esfera dourada no telhado marca cada melhoria. Os dados ficam em
  `Content/Data/Upgrades.json`.
- **Quiosque e comida:** vende água de coco de base; melhorias adicionam bebidas, lanches, petiscos e
  drinks ao cardápio. Com a mira no quiosque, **5** contrata atendente (mais clientes ao mesmo tempo;
  o primeiro é o dono, de graça) e **6** instala o caixa registradora (atendimento 30% mais rápido).
- **Equipe:** garçons (+6% de renda em comida, hospedagem e spa) e faxineiros (+satisfação por visita),
  até 5 de cada, com salário diário.
- **Terreno:** começa pequeno (18 m de largura) e a praia é ampliada a cada novo nível do resort
  (até 60 m, crescendo a cada um dos 20 níveis). Uma cerca branca marca o limite.
- **Quiosque que evolui:** cada melhoria acrescenta algo ao quiosque (placa, mesas, deck, pérgola com
  luzes) e o nome muda: Quiosque, Quiosque Reformado, Bar do Quiosque, Beach Bar, Restaurante Beira-Mar.
- **Quartos individuais:** chalés e hotel têm cada quarto com nível próprio (0 a 3); os hóspedes ocupam
  primeiro os melhores. **Preço:** -/+ muda o preço de qualquer construção (caro rende mais, mas cansa o
  hóspede). Lojas de comida gastam 25% da venda em produtos.
- **Estrelas:** cada melhoria sobe a construção em 1 estrela (até 5); hóspedes ricos preferem as de mais estrelas.
- **Prestígio** sobe o **nível** do resort (**20 níveis**, do Quiosque Simples ao Resort Lendário). Cada
  nível libera novas construções (22 no total) e hóspedes mais ricos, e dá bônus em dinheiro. A cada 4
  níveis muda a fase (visual do cenário). Há 31 missões encadeadas.
- **Campanha longa:** um jogador perfeito chega ao nível 20 por volta do dia 330 (~22 h); um jogador
  normal deve levar 30 h ou mais. Ajuste com `python3 Tools/simular_balanceamento.py 360 1`.
- Cada construção tem **manutenção diária**. Sem dinheiro para pagar, o prestígio cai.
- O dia dura 4 minutos reais (das 8h às 20h) e o sol se move no céu.

## Balanceamento (sem mexer em código)

Os números ficam em `Content/Data/Buildings.json` e `Content/Data/Guests.json`.
Para editar com acentos facilmente, altere `Tools/gerar_dados.py` e rode:

```
python Tools/gerar_dados.py
```

Guia completo de arte: veja [ASSETS.md](ASSETS.md).

## Trocar uma forma básica por um modelo 3D final

1. Importe ou adicione o modelo ao projeto (Fab, ou arraste o arquivo no Content Browser).
2. Botão direito no asset → **Copy Reference** e cole o caminho em `MESH_OVERRIDES`
   dentro de `Tools/gerar_dados.py` (há um exemplo comentado).
3. Rode `python Tools/gerar_dados.py`. Ajuste `MeshScale`, `MeshYaw` e `MeshOffset`
   até encaixar na caixa de colisão (`Size`).

Se o modelo não for encontrado, o jogo volta às formas básicas e avisa no Output Log.

## Trocar os bonecos por pessoas 3D (hóspedes e funcionários)

O jogo já está pronto para receber os modelos; é só apontar para eles em `Tools/gerar_dados.py`
(`GUEST_MODELS` e `STAFF_MODELS`) e rodar `python Tools/gerar_dados.py`:

- **Mesh:** o SkeletalMesh da pessoa (botão direito > Copy Reference no Content Browser).
- **AnimClass:** o Animation Blueprint, com `_C` no final (opcional; sem ele o modelo fica parado).
- **MeshScale / MeshYaw / MeshOffsetZ:** ajustes de tamanho, giro (padrão -90) e altura dos pés.
- Funções dos funcionários: `attendant` (atendente da loja), `waiter` (garçom), `cleaner` (faxineiro).

Se o modelo não for achado, o jogo usa o boneco básico e avisa no Output Log.

## Sons

Os sons são gerados por código (`ResortAudio`), sem arquivos: mar contínuo, gaivotas, moedas quando
um hóspede paga, batida ao construir e um sinal ao comprar melhorias. São provisórios; dá para trocar
por áudio de verdade depois.

## Mar e areia

O mar tem ondas (cristas que viajam até a praia, espuma que avança e recua, areia molhada que
acompanha, mar que sobe e desce) e a areia tem manchas de tom, marcas de onda, conchas e pedras.
Tudo isso é provisório feito por código. Para água e areia de verdade: ative o plugin **Water**
e use materiais de areia do Fab/Quixel (me mande os caminhos que eu ligo no jogo).

## Estrutura

```
Source/SimuladorUe/
  ResortGameMode   monta praia, mar, céu/sol, palmeiras, quiosque inicial; gera hóspedes
  ResortCharacter  jogador em 1ª pessoa + modo construção (entrada criada por código)
  BuildingActor    uma construção (visual provisório montado por formas básicas)
  GuestCharacter   hóspede (escolhe, anda, usa, paga, vai embora)
  ResortEconomy    dinheiro, prestígio, nível, relógio, lista de construções
  StaffCharacter   garçom e faxineiro que circulam pela praia
  ResortHUD        interface desenhada no Canvas (sem UMG)
  ResortData       leitura dos JSON em Content/Data
Content/Data/      Buildings.json, Guests.json
Config/            renderização (Lumen/Nanite), canal de colisão, entrada
```

## Próximos passos

- Visual final: assets do Fab/Quixel, água com o plugin Water, materiais estilizados,
  pós-processo com contorno suave.
- Mais hóspedes com personalidade, filas e reclamações.
- Menu inicial, sons e música.
- Pacote (build) para Windows.
